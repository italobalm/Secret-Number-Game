//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametroBolinha = 23;
let raio = diametroBolinha / 2;

//variáveis de velocidade
let velocidadexBolinha = 6;
let velocidadeyBolinha = 6;

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

//variáveis do oponente
let xRaqueteOponente = 585;
let yRaqueteOponente = 150;
let velocidadeYOponente;

let colidiu = false;

//placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//sons do jogo
let somRaquetada;
let somDoPonto;
let somTrilha;

function preload(){
  somTrilha = loadSound("trilha.mp3");
  somPonto = loadSound("ponto.mp3");
  somRaquetada = loadSound("raquetada.mp3");
}
function setup() {
  createCanvas(600, 400);
  somTrilha.loop();
}

//desenho do jogo
function draw() {
  background(32,178,170);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostrarRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  //verificaColisaoRaquete();
  verificaColisaoRaquete(xRaquete, yRaquete);
  mostrarRaquete(xRaqueteOponente, yRaqueteOponente);
  movimentaRaqueteOponente();
  verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  incluiPlacar();
  marcaPonto();
  
  
function mostraBolinha(){
  circle(xBolinha, yBolinha, diametroBolinha);
}
function movimentaBolinha(){
  xBolinha += velocidadexBolinha;
  yBolinha += velocidadeyBolinha;
}
function verificaColisaoBorda(){
   
  if (xBolinha + raio > width || xBolinha - raio < 0){
    velocidadexBolinha *= -1;
  }
  if (yBolinha + raio > height || yBolinha - raio < 0){
    velocidadeyBolinha *= -1;
  }
  
}
function mostrarRaquete(x, y){
  rect(x, y, raqueteComprimento, raqueteAltura);
}
function movimentaMinhaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -=10;
  }
  if (keyIsDown(DOWN_ARROW)){
      yRaquete +=10;
      }
   yRaquete = constrain(yRaquete, 10, 310);
}
//function verificaColisaoRaquete(){
  //lados da bolinha
let esquerdaBolinha = xBolinha - raio;
let superiorBolinha = yBolinha - raio;
let inferiorBolinha = yBolinha + raio;

//lados da raquete
let direitaRaquete = xRaquete + raqueteComprimento;
let superiorRaquete = yRaquete;
let inferiorRaquete = yRaquete + raqueteAltura;

  if (esquerdaBolinha < direitaRaquete && superiorBolinha < inferiorRaquete && inferiorBolinha > superiorRaquete){
    velocidadexBolinha *= -1;
    somRaquetada.play();
  }
}
function verificaColisaoRaquete(x,y){
  colidiu = 
  collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadexBolinha *= -1
    somRaquetada.play();
  }
}
function movimentaRaqueteOponente(){
  if (keyIsDown(87)){
    yRaqueteOponente -=10;
}
  if (keyIsDown(83)){
    yRaqueteOponente +=10;
  }
}
function incluiPlacar(){
  textAlign(CENTER)
  textSize(18);
  stroke(255);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20)
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255,140,0));
  rect(410, 10, 40, 20)
  fill(255);
  text(pontosDoOponente, 430, 26);
}
function marcaPonto(){
  if (xBolinha > 590){
    meusPontos +=1;
    somPonto.play();
  }
  if (xBolinha < 10){
    pontosDoOponente +=1;
    somPonto.play();
  }
}

function bolinhaNaoFicaPresa(){
    if (XBolinha - raio < 0){
    XBolinha = 23
    }
}
